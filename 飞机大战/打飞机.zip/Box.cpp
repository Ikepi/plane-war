#include "stdafx.h"

#include "Box.h"
#include "BlackBoard.h"
#include "UIController.h"

Box::Box(int left, int top, int r, int c) : _left(left), _top(top), _row(r), _col(c)
{

}

